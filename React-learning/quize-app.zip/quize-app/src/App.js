import React, { Component } from "react";
import "./App.css";
import QuizeComponent from "./components/QuizeComponent";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      points: 0,
      pageNum: 0,
      quizeData: [
        {
          id: 1,
          question: "who is the prime minister of india?",
          options: [
            "rajendra prasad",
            "radha krishnan",
            "narendra modi",
            "obama",
          ],
          ans: "narendra modi",
        },
        {
          id: 2,
          question:
            "Grand Central Terminal, Park Avenue, New York is the world's",
          options: [
            "rajendra prasad",
            "radha krishnan",
            "largest railway station",
            "obama",
          ],
          ans: "largest railway station",
        },
        {
          id: 3,
          question: "Entomology is the science that studies",
          options: ["rajendra prasad", "radha krishnan", "Insects", "obama"],
          ans: "Insects",
        },
        {
          id: 4,
          question:
            "Eritrea, which became the 182nd member of the UN in 1993, is in the continent of",
          options: ["rajendra prasad", "radha krishnan", "Africa", "obama"],
          ans: "Africa",
        },
        {
          id: 5,
          question: "Garampani sanctuary is located at",
          options: ["Diphu, Assam", "radha krishnan", "narendra modi", "obama"],
          ans: "Diphu, Assam",
        },
        {
          id: 6,
          question: "Hitler party which came into power in 1933 is known as",
          options: ["Diphu, Assam", "Nazi Party", "narendra modi", "obama"],
          ans: "Nazi Party",
        },
      ],
      userSelection: "",
      color: "#fff",
    };
  }

  getAns = (selectedValue) => {
    const { quizeData, pageNum, points } = this.state;
    if (selectedValue === quizeData[pageNum].ans) {
      console.log("pageNum=>", pageNum, "quizeData.length", quizeData.length);
      if (pageNum !== quizeData.length - 1) {
        this.setState({ color: "green", points: points + 1 });
        this.debouncer(pageNum, quizeData, points);
        // console.log(points)
      } else {
        this.setState({ color: "green" });
        this.debouncer(pageNum, quizeData);
        // console.log(points)
      }
    } else {
      this.setState({ color: "red" });
      this.debouncer(pageNum, quizeData);
    }
  };

  debouncer = (pageNum, quizeData) => {
    if (pageNum !== quizeData.length - 1) {
      setTimeout(() => {
        this.setState({ pageNum: pageNum + 1, color: "#fff" });
      }, 1000);
    }
  };

  clickFinish = () => {
    alert("Your score is: " + this.state.points * 5);
  };

  render() {
    const { points, pageNum, quizeData, color } = this.state;
    return (
      <div className="App">
        <header className="AppHeader">
          <div className="AppHeading">Super Quize App</div>
          <div className="Points">Points: {points * 5}</div>
        </header>
        <QuizeComponent
          quizeData={quizeData[pageNum]}
          getAns={this.getAns}
          color={color}
        />
        <div className="App-btn">
          {pageNum === quizeData.length - 1 && (
            <button onClick={this.clickFinish} className="Submit">
              Finish
            </button>
          )}
        </div>
      </div>
    );
  }
}

export default App;
