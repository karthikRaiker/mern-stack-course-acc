import React, { Component } from 'react';
import Qimg from '../images/slot-img.PNG';
import "./index.css"

class QuizeComponent extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        const {quizeData, color} = this.props;
       
        return (
            <div className='Quize'>
                <div className='Quize-Question'>
                    <div className='Quize-Question-title'>Question Title</div>
                    <div className='Quize-Question-Question'>{quizeData.id}. {quizeData.question}</div>
                </div>
                <div className='Quize-Ans-Container' style={{backgroundColor:color}}>
                    <div className='Quize-Ans-img'>
                        <img src={Qimg} alt='' />
                    </div>
                    <div className='Quize-Ans-Option'>
                        {quizeData.options.length ? quizeData.options.map((item,index)=>{
                             return <div className='Quize-Ans-Option-Item' onClick={()=>{this.props.getAns(item)}} key={index}>{item}</div>
                        }):""}
                    </div>
                </div>
            </div>
        );
    }
}

export default QuizeComponent;